"""Standalone skill package validation."""
